<?php
include ('funcaoCliente.php');
?>